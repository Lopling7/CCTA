package edu.oakland.production.gui;

import edu.oakland.production.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import javax.swing.*;

public class alternateGUI extends JFrame {
	private JLabel namePrompt;
	public JTextField nameLabel;
	private JLabel timePrompt;
	public JTextField timeLabel;
	private JLabel contactPrompt;
	public JTextField contactLabel;
	private JLabel maskPrompt;
	public JTextField maskLabel;
	private JLabel vaxPrompt;
	public JTextField vaxLabel;
	private JButton saveBtn;
	private JButton cancelBtn;
	
	public log mainLog;
	public String list;

	public alternateGUI() {
		JPanel panel = new JPanel();
		setLayout(new BorderLayout());
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int width = screenSize.width;
		int height = screenSize.height;
		namePrompt = new JLabel("Name:");
		nameLabel = new JTextField("               ");
		namePrompt.setLocation(0, 0);
		nameLabel.setLocation(0, 100);
		timePrompt = new JLabel("Time:");
		timeLabel = new JTextField("               ");
		timePrompt.setLocation(80, 0);
		timeLabel.setLocation(80, 100);
		contactPrompt = new JLabel("Phone#:");
		contactLabel = new JTextField("               ");
		contactPrompt.setLocation(160, 0);
		contactLabel.setLocation(160, 100);
		maskPrompt = new JLabel("Mask?:");
		maskLabel = new JTextField("               ");
		maskPrompt.setLocation(240, 0);
		maskLabel.setLocation(240, 100);
		vaxPrompt = new JLabel("Vaccine Status:");
		vaxLabel = new JTextField("               ");
		vaxPrompt.setLocation(320, 0);
		vaxLabel.setLocation(320, 100);
		saveBtn = new JButton("Save Changes");
		cancelBtn = new JButton("Cancel");
		
		
		add(panel);
		panel.add(namePrompt);
		panel.add(nameLabel);
		panel.add(timePrompt);
		panel.add(timeLabel);
		panel.add(contactPrompt);
		panel.add(contactLabel);
		panel.add(maskPrompt);
		panel.add(maskLabel);
		panel.add(vaxPrompt);
		panel.add(vaxLabel);
		panel.add(saveBtn);
		panel.add(cancelBtn);
		saveBtn.setLocation(500, 0);
		cancelBtn.setLocation(500, 100);
		mainLog = new log("12/01/2021"); //should be changed to date inputted at beginning
		

		saveBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mainLog.addEntry(nameLabel.getText(), timeLabel.getText(), contactLabel.getText(),
						maskLabel.getText(), vaxLabel.getText());
				list = (nameLabel.getText() + timeLabel.getText() + contactLabel.getText()
						+ maskLabel.getText() + vaxLabel.getText());
				mainGUI mGUI = new mainGUI();
				mainGUILaunch mGUIL = new mainGUILaunch();
				mGUIL.main(null);
				setVisible(false);
			}
		});
		cancelBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mainGUILaunch mGUIL = new mainGUILaunch();
				mGUIL.main(null);
				nameLabel = new JTextField("               ");
				timeLabel = new JTextField("               ");
				contactLabel = new JTextField("               ");
				maskLabel = new JTextField("               ");
				vaxLabel = new JTextField("               ");
				setVisible(false);
			}
		});
	}
}
