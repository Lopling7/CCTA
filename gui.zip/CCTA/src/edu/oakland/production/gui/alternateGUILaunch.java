package edu.oakland.production.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class alternateGUILaunch {
	public static void main(String[] args) {
		alternateGUI aGUI = new alternateGUI();
		aGUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		aGUI.setTitle("CCTA: Add/Edit Screen");
		aGUI.setSize(540, 680);
		aGUI.setLocation(50, 50);
		aGUI.setVisible(true);
	}
}