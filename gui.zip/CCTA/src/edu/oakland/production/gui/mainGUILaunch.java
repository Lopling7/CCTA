package edu.oakland.production.gui;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class mainGUILaunch {
	public static void main(String[] args) {
		mainGUI mGUI = new mainGUI();
		mGUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mGUI.setTitle("CCTA: Main Screen");
		mGUI.setSize(540, 680);
		mGUI.setLocation(50, 50);
		mGUI.setVisible(true);
	}
}