package edu.oakland.production.gui;

import java.awt.*;
import java.awt.event.*;
import java.util.*;

import javax.swing.*;

public class mainGUI extends JFrame {
	private JButton addBtn;
	private JButton editBtn;
	public String date = "12/01/2021";
	private JLabel dateLabel;
	private JLabel chartCols;
	public JPanel p;
	public JList mLog;
	
	private Scanner sc;
	public boolean startFlag = true;
	
	public alternateGUI aGUI;

	public mainGUI() {
		setLayout(new FlowLayout());
		addBtn = new JButton("Add");
		editBtn = new JButton("Update");
		chartCols = new JLabel("Name    Time    Contact     Mask    Vaccination");
		p = new JPanel();
		
		//date request
//		if (startFlag) {
//			sc = new Scanner(System.in);
//			System.out.print("Enter the Date (MM/DD/YYYY): ");
//			date = sc.next();
//		}
		dateLabel = new JLabel(date);
		
		aGUI = new alternateGUI();
		mLog = new JList();
		int i = 0;
		while (i <= aGUI.mainLog.counter) {
			mLog.add(aGUI.mainLog.logArr[i], getComponent(0));
			i++;
		}
		add(addBtn);
		add(editBtn);
		add(dateLabel);
		add(chartCols);

		addBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				alternateGUILaunch aGUIL = new alternateGUILaunch();
				aGUIL.main(null);
				setVisible(false);
			}
		});
		editBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				alternateGUILaunch aGUIL = new alternateGUILaunch();
				aGUIL.main(null);
				setVisible(false);
			}
		});
	}
}
