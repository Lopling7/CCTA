package edu.oakland.production;

import java.util.Arrays;

import javax.swing.text.*;

public class log {
	public String[] logArr = new String[25];
	public int counter = -1;
	public String date;
	
	public log(String theDate) {
		date = theDate;
	}
	
	public void addEntry(String name, String time, String contact, String mask, String vax) {
		counter++;
		logArr[counter] = (name + time + contact + mask + vax);
	}
}