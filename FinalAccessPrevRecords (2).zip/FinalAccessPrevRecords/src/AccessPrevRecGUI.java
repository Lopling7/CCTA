import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class AccessPrevRecGUI {
	private static JLabel dateLabel;
	private static JTextField prev_date;
	private static JLabel displayLabel;
	private static JLabel displaylogName;
	private static JLabel displaylogTime;
	private static JLabel displaylogContact;
	private static JLabel displaylogMask;
	private static JLabel displaylogVax;		

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JPanel panel = new JPanel();
		JFrame frame = new JFrame();
		frame.setSize(560,400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		
		// put the panel on the frame
		frame.add(panel);
				
		panel.setLayout(null);
				
		frame.setTitle("Access Previous Logs");
		
		
		
		dateLabel = new JLabel("Select a date (MM/DD/YY): ");
		dateLabel.setBounds(15,50,200,25);
		panel.add(dateLabel);
		
		
		
		DateFormat dateFormat = new SimpleDateFormat("M/d/yy");
		JFormattedTextField prev_date = new JFormattedTextField(dateFormat);
		
		
		//prev_date = new JTextField();
		prev_date.setBounds(185,50,150,25);
		panel.add(prev_date);
		
		
		
		Date date = new Date();
		Calendar cal = Calendar.getInstance();
		//prev_date.Simple

	
		
		JButton button = new JButton("Submit");
		button.setBounds(350, 50, 175, 25);
		panel.add(button);
		
		// if the log exists in the system
		// if (log != null){
		//   ButtonAdd Action Listener Performed is done here
		
		// displays the previous log
		// }
		// otherwise, return null
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String previous_date = prev_date.getText();
				//System.out.println( "Displaying log for " + previous_date);
				displayLabel = new JLabel( "Displaying log for " + previous_date);
				displayLabel.setBounds(15,75,200,25);
				panel.add(displayLabel);
				
			/*	// Add these get-methods to alternateGUI.java so that we can retrieve the data
				public JTextField getNameLabel() {
					return this.nameLabel;
				}
				
				public JTextField getTimeLabel() {
					return this.timeLabel;
				}
				
				
				public JTextField getContactLabel() {
					return this.contactLabel;
				}
				
				public JTextField getmaskLabel() {
					return this.maskLabel;
				}
			
				
				public JTextField getVaxLable() {
					return this.vaxLabel; 
				}
			*/
				
				displaylogName = new JLabel("Name:  " + getNameLabel());
				displaylogName.setBounds(20,100,200,25);
				
				displaylogTime = new JLabel("Time: " + getTimeLabel());
				displaylogTime.setBounds(20,125,200,25);
				
				
				displaylogContact = new JLabel("Contact: " + getContactLabel());
				displaylogContact.setBounds(20,150,200,25);
				
				
				displaylogMask = new JLabel("Mask: " + getmaskLabel());
				displaylogMask.setBounds(20,175,200,25);
				
				displaylogVax = new JLabel("Vaxination Status: " + getVaxLabel());
				displaylogVax.setBounds(20,200,200,25);
				
				
				panel.add(displaylogName);
				panel.add(displaylogTime);
				panel.add(displaylogContact);
				panel.add(displaylogMask);
				panel.add(displaylogVax);
		
		
				// Unnecessary coding-- if the above does not display, then uncomment this
				//panel.add(getNameLabel());
				//panel.add(getTimeLabel());
				//panel.add(getContactLabel());
				//panel.add(getmaskLabel());
				//panel.add(getVaxLabel());
				
				
			}
		});

		frame.setVisible(true);
	}
	
	
	
}
