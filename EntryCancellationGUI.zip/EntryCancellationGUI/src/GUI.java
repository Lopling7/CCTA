import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.event.*;
//import java.awt.event.ActionListener;


public class GUI implements ActionListener{
	 private static JLabel cancelChangesLabel;
	 private static JLabel warningCancelChanges;
	 private static  JButton y_button;
	 private static JButton n_button;
	 
	 
	public static void main(String[] args) {
		
		
			
		// use a Boolean variable to choose between choice 1(if user entered through the add button or the edit button
		boolean choice1= true; // will determine if user entered through the cancel add button
		boolean choice2 = true; // will determine if user entered though the cancel edit button
	
		
	
		
		// TODO Auto-generated method stub
		JPanel panel = new JPanel();
		JFrame frame = new JFrame();
		frame.setSize(450,200);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//frame.setTitle("Cancel"); // sets the title of the popup window
		frame.setTitle("Cancel Changes");
		
		
		//frame.setTitle("Cancel Add");
		//frame.setTitle("Cancel Edit");
		
		// put the panel on the frame
		frame.add(panel);
		panel.setLayout(null);
		
		
		
/*	// If the user enters the cancel button through the edit screen...
		cancelChangesLabel = new JLabel("Are you sure you want to cancel editing the entry?");
		cancelChangesLabel.setBounds(50, 30, 300, 25);
		panel.add(cancelChangesLabel);
		
		
		y_button = new JButton("yes");
		y_button.setBounds(50,80,80,25);
		panel.add(y_button);
		
		n_button = new JButton("no");
		n_button.setBounds(200,80,80,25);
		panel.add(n_button); 
*/		
	
		
		
		//
	if(choice1 == true) {
		// If the user enters the cancel button through the add screen...
		cancelChangesLabel = new JLabel("Are you sure you want to cancel adding a new entry?");
		cancelChangesLabel.setBounds(50, 30, 300, 25);
		panel.add(cancelChangesLabel);
		
		
		y_button = new JButton("yes");
		y_button.setBounds(50,80,80,25);
		panel.add(y_button);
		
		y_button.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				// NOTE: THESE VARIABLES BELOW NEED TO MATCH AND REFER TO THE VARIABLES IN THE PRIMARY CCTA
				// CHANGE THESE SO THAT THEY REFER TO THOSE
			      textBox1.setText("");   //<---- change textBox1 to the field name of the CCTA input fields
			      name.setText("");   //
			      time.setText(""); 
			      contact.setText(""); 
			      mask.setText(""); 
			      vax.setText(""); 
				
				 System.exit(0); // closes the GUI
			}});

		
		// add action listeners to the yes and no buttons
		n_button = new JButton("no");
		n_button.setBounds(200,80,80,25);
		panel.add(n_button);	
		
		// Adding an ActionListener to the No button
		n_button.addActionListener(new ActionListener() {

		public void actionPerformed(ActionEvent e) { 
			
			 System.exit(0); // closes the GUI
		}});
		
			
		}
		
		if(choice2 == false) {
			// If the user enters the cancel button through the edit screen...
			cancelChangesLabel = new JLabel("Are you sure you want to cancel editing the entry?");
			cancelChangesLabel.setBounds(50, 30, 300, 25);
			panel.add(cancelChangesLabel);
			
			warningCancelChanges = new JLabel("Changes you made will not be saved");
			warningCancelChanges.setBounds(50, 40, 310, 30);
			panel.add(warningCancelChanges);
			
			
			y_button = new JButton("yes");
			y_button.setBounds(50,80,80,25);
			panel.add(y_button);
			
			
			//Adding an ActionListener to Yes button
			y_button.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) { 
		    	// DO SOMETHING HERE THAT:
			    	// deletes and does not save the changes made by the user
			    	// close and take back to the main landing page
		    	
					    //selectionButtonPressed();
					   // n_button = new JButton("no");
						//n_button.setBounds(200,80,80,25);
						//panel.add(n_button);
						
			}});
			
			
			n_button = new JButton("no");
			n_button.setBounds(200,80,80,25);
			panel.add(n_button);	
			
			// Adding an ActionListener to the No button
			n_button.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				
				// DO SOMETHING HERE SO THAT THE CHANGES ARE INTACT User can go back to editing what they were editing without interruptions
				// --! DON'T KNOW HOW TO DO THIS :(
				
				 System.exit(0); // closes the GUI
			}});
			
			
			
			
		}
		
		
		
		// System.out.println("Are you sure you want to delete this entry?");
		
		// Prompt user are you sure you want to delete entry?
		// provide options yes no
		
		
		// if from entry cancel to delete a log, dosplay title "Delete log?"
		// of from entry update display title "Cancel changes"
		frame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
