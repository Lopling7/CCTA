import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class AccessPrevRecGUI {
	private static JLabel dateLabel;
	private static JTextField prev_date;
	private static JLabel displayLabel;
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JPanel panel = new JPanel();
		JFrame frame = new JFrame();
		frame.setSize(560,400);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		
		// put the panel on the frame
		frame.add(panel);
				
		panel.setLayout(null);
				
		frame.setTitle("Access Previous Logs");
		
		
		
		dateLabel = new JLabel("Select a date (MM/DD/YY): ");
		dateLabel.setBounds(15,50,200,25);
		panel.add(dateLabel);
		
		
		
		DateFormat dateFormat = new SimpleDateFormat("M/d/yy");
		JFormattedTextField prev_date = new JFormattedTextField(dateFormat);
		
		
		//prev_date = new JTextField();
		prev_date.setBounds(185,50,150,25);
		panel.add(prev_date);
		
		
		
		Date date = new Date();
		Calendar cal = Calendar.getInstance();
		//prev_date.Simple

	
		
		JButton button = new JButton("Submit");
		button.setBounds(350, 50, 175, 25);
		panel.add(button);
		
		// if the log exists in the system
		// if (log != null){
		//   ButtonAdd Action Listener Performed is done here
		
		// displays hte previous log
		// }
		// otherwise, return null
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String previous_date = prev_date.getText();
				//System.out.println( "Displaying log for " + previous_date);
				displayLabel = new JLabel( "Displaying log for " + previous_date);
				displayLabel.setBounds(15,75,200,25);
				panel.add(displayLabel);
			}
		});

			
		
		
		// Shows "Displaying log from" --> textbox: date
		
		
		
		// Implement methods that abstract the contents from the given log and display it on the screen
		
		frame.setVisible(true);
	}
	
	
	
}
